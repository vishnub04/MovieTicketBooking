package com.theatre.service;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.theatre.dao.TheatreDAOImpl;
import com.theatre.model.TheatreDTO;

@Service
@Transactional
public class TheatreServiceImpl implements TheatreService{
@Autowired
TheatreDAOImpl theatreDAO;


//-------------------------add theatre-------------------------------------------//


	@Override
	public void addTheatre(TheatreDTO theatre) throws Exception {

			TheatreDTO a=new TheatreDTO();
			a=theatreDAO.checkTheatre(theatre.getTheatre_name());
			
		
			if(a!=null)
			{
			throw new Exception("Service.THEATRE_ALREADY_EXISTS");
		
			}
			if(a==null) {
				theatreDAO.addTheatre(theatre);
			}
			
	
	}
	
			
		
	
	
	//-------------------------update theatre-------------------------------------------//
	
	
	@Override
	public void updateTheatre(TheatreDTO theatre) throws Exception {
		
		Boolean a=theatreDAO.updateTheatre(theatre);
		if(a==false) {
			throw new Exception("Service.THEATRE_DOES_NOT_EXIST");
		}
	
		
}	
	
	
	//-------------------------delete theatre-------------------------------------------//
	
	
	
	@Override
	public void deleteTheatre(TheatreDTO theatre) throws Exception{
		Boolean a=theatreDAO.deleteTheatre(theatre);
		if(a==false) {
			throw new Exception("Service.THEATRE_DOES_NOT_EXIST");
		}
	}
	
	//-------------------------get theatre-------------------------------------------//
	
	
	@Override
	public List<TheatreDTO> getTheatre() throws Exception{
		List<TheatreDTO> returnList=new ArrayList<TheatreDTO>();
		returnList=theatreDAO.getTheatre();
		
		
		
		if(returnList.isEmpty()) {
			throw new Exception("Service.THEATRE_LIST_IS_EMPTY");
		}
		return returnList;
		
		
	}
	}

	