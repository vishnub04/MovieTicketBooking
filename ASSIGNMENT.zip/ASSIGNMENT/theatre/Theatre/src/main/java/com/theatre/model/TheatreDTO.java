package com.theatre.model;

public class TheatreDTO {
	private String theatre_name;
	private String theatre_location;
	private Integer price;
	private Float rating;
	private Integer SeatingCapacity;
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public String getTheatre_location() {
		return theatre_location;
	}
	public void setTheatre_location(String theatre_location) {
		this.theatre_location = theatre_location;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Float getRating() {
		return rating;
	}
	public void setRating(Float rating) {
		this.rating = rating;
	}
	public Integer getSeatingCapacity() {
		return SeatingCapacity;
	}
	public void setSeatingCapacity(Integer seatingCapacity) {
		SeatingCapacity = seatingCapacity;
	}
	
	
}
