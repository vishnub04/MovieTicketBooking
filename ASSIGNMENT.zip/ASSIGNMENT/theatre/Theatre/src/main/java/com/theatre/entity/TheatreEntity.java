package com.theatre.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="theatre")
public class TheatreEntity {
	@Id
	@Column(name="theatre_name")
	private String theatre_name;
	@Column(name="theatre_location")
	private String theatre_location;
	@Column(name="price")
	private Integer price;
	@Column(name="rating")
	private Float rating;
	@Column(name="seating_capacity")
	private Integer seatingCapactity;
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Float getRating() {
		return rating;
	}
	public void setRating(Float rating) {
		this.rating = rating;
	}
	public Integer getSeatingCapactity() {
		return seatingCapactity;
	}
	public void setSeatingCapactity(Integer seatingCapactity) {
		this.seatingCapactity = seatingCapactity;
	}
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public String getTheatre_location() {
		return theatre_location;
	}
	public void setTheatre_location(String theatre_location) {
		this.theatre_location = theatre_location;
	}

}
