package com.theatre.service;

import java.util.List;

import com.theatre.model.TheatreDTO;

public interface TheatreService {
	public void addTheatre(TheatreDTO theatre) throws Exception;
	public void updateTheatre(TheatreDTO theatre) throws Exception;
	public void deleteTheatre(TheatreDTO theatre) throws Exception;
	public List<TheatreDTO> getTheatre() throws Exception;
	
	
}
