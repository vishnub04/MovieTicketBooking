package com.theatre.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.theatre.entity.TheatreEntity;
import com.theatre.model.TheatreDTO;


@Repository
public class TheatreDAOImpl implements TheatreDAO{

	
	@PersistenceContext
	private EntityManager em;
	
	
	//-------------------------add theatre-------------------------------------------//
	
	
	@Override
	public void addTheatre(TheatreDTO theatre) throws Exception {
		
	
		TheatreEntity theatreEntity=new TheatreEntity();
		theatreEntity.setTheatre_name(theatre.getTheatre_name());
		theatreEntity.setPrice(theatre.getPrice());
		theatreEntity.setTheatre_location(theatre.getTheatre_location());
		theatreEntity.setRating(theatre.getRating());
		theatreEntity.setSeatingCapactity(theatre.getSeatingCapacity());
		em.persist(theatreEntity);
		
	
		}
	
	
	
	//-------------------------update theatre-------------------------------------------//
	
	
	
	
	@Override
	public Boolean updateTheatre(TheatreDTO theatre) throws Exception {
	
		TheatreEntity theatreEntity=em.find(TheatreEntity.class,theatre.getTheatre_name());
		if(theatreEntity!=null) {
			theatreEntity.setPrice(theatre.getPrice());
			theatreEntity.setRating(theatre.getRating());
			theatreEntity.setSeatingCapactity(theatre.getSeatingCapacity());
			Query query=em.createQuery("select a from TheatreEntity a where a.theatre_name=:theatreName");
			query.setParameter("theatreName" , theatreEntity.getTheatre_name());
			List<TheatreEntity> theatreList=query.getResultList();
			
			for(TheatreEntity a: theatreList) {
				
				a.setPrice(theatreEntity.getPrice());
				a.setRating(theatreEntity.getRating());
				a.setSeatingCapactity(theatreEntity.getSeatingCapactity());
			
			}return true;
		}return false;
	
	}
	
	
	//-------------------------delete theatre-------------------------------------------//
	
	
	@Override
	public Boolean deleteTheatre(TheatreDTO theatre) throws Exception{
			TheatreEntity theatreEntity=em.find(TheatreEntity.class,theatre.getTheatre_name());
			if(theatreEntity!=null) {
				em.remove(theatreEntity);
			 return true;
			 }
			return false;
	
	}
	
	
	//-------------------------get all theatre-------------------------------------------//
	
	@Override
	public List<TheatreDTO> getTheatre() throws Exception{
			
			List<TheatreDTO> returnList=new ArrayList<TheatreDTO>();
			Query query=em.createQuery("select u from TheatreEntity u");
			List<TheatreEntity> theatreEntity=query.getResultList();
			for(TheatreEntity a: theatreEntity) {
				TheatreDTO theatreData=new TheatreDTO();
				theatreData.setTheatre_name(a.getTheatre_name());
				theatreData.setTheatre_location(a.getTheatre_location());
				theatreData.setSeatingCapacity(a.getSeatingCapactity());
				theatreData.setRating(a.getRating());
				theatreData.setPrice(a.getPrice());
				returnList.add(theatreData);
			}
			
		return returnList;
	}
	
	
	//-------------------------get  theatre-------------------------------------------//
	@Override
	public TheatreDTO checkTheatre(String theatre_name) throws Exception{
		TheatreEntity theatre=em.find(TheatreEntity.class,theatre_name);
		if(theatre!=null) {
			TheatreDTO details=new TheatreDTO();
			details.setTheatre_name(theatre.getTheatre_name());
			details.setTheatre_location(theatre.getTheatre_location());
			return details;
		}
		return null;
	}
}
