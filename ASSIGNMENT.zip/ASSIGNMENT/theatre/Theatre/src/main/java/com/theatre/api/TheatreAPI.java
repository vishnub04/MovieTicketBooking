package com.theatre.api;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.theatre.model.TheatreDTO;
import com.theatre.service.TheatreServiceImpl;

@RestController
@CrossOrigin
@RequestMapping(value="/theatre")
public class TheatreAPI {
	@Autowired
	private Environment env;
	
	//=====================================add theatre====================================================//
	
	@Autowired
	TheatreServiceImpl theatreService;
	
	@PostMapping(value="/addTheatre")
	public JSONObject addTheatre(@RequestBody TheatreDTO theatre) throws Exception {
		try {
	theatreService.addTheatre(theatre);
	JSONObject j=new JSONObject();
	String name=theatre.getTheatre_name();
	 j.put(name,"successfully_added");
	 return j;
		}
		catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	
}
	
	
	//=====================================update theatre====================================================//
	
	@PostMapping(value="/updateTheatre")
	public JSONObject updateTheatre(@RequestBody TheatreDTO theatre) throws Exception {
		try {
			theatreService.updateTheatre(theatre);
			JSONObject j=new JSONObject();
			String name=theatre.getTheatre_name();
			 j.put(name,"successfully_updated");
			 return j;
			 
	}catch(Exception e) {
		throw new ResponseStatusException(HttpStatus.BAD_REQUEST ,env.getProperty(e.getMessage()));
	}
	}
	
	//=====================================delete theatre====================================================//
	@PostMapping(value="/deleteTheatre")
	public JSONObject deleteTheatre(@RequestBody TheatreDTO theatre) throws Exception {
		try {
			theatreService.deleteTheatre(theatre);
			JSONObject j=new JSONObject();
			String name=theatre.getTheatre_name();
			 j.put(name,"successfully_deleted");
			 return j;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST ,env.getProperty(e.getMessage()));
		}
	}
		
	//=====================================get all theatre====================================================//
	
	@GetMapping(value="/getTheatre")
	public ResponseEntity <List<TheatreDTO>> getTheatre() throws Exception { 
		try {
		List<TheatreDTO> returnList=new ArrayList<TheatreDTO>();
		returnList=theatreService.getTheatre();
		ResponseEntity<List<TheatreDTO>> theatreList=new ResponseEntity<List<TheatreDTO>>(returnList,HttpStatus.OK);
		
		return theatreList;
	}catch(Exception e) {
		throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
	}
	}
}
