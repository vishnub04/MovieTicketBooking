package com.theatre.dao;

import java.util.List;

import com.theatre.entity.TheatreEntity;
import com.theatre.model.TheatreDTO;

public interface TheatreDAO {
	public void addTheatre(TheatreDTO theatre) throws Exception;
	public Boolean updateTheatre(TheatreDTO theatre) throws Exception;
	public Boolean deleteTheatre(TheatreDTO theatre) throws Exception;
	public List<TheatreDTO>  getTheatre() throws Exception;
	public TheatreDTO checkTheatre(String theatre_name) throws Exception;
}
