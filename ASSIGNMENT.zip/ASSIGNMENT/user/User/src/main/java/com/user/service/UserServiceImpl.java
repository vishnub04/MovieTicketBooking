package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.user.dao.UserDAOImpl;
import com.user.model.LoginDTO;
import com.user.model.UserDTO;

@Service
@Transactional

public class UserServiceImpl implements UserService {
	
@Autowired
UserDAOImpl userDAO;
@Autowired
private Environment env;
	@Override
	public void addUser(UserDTO user) throws Exception {
		UserDTO userVer=new UserDTO();
		userVer=userDAO.getUser(user.getUserName());
		if(userVer==null) {
		
		userDAO.addUser(user);
	}
		if(userVer!=null) {
			throw new Exception("Service.USER_ALREADY_EXISTS");

		}
	}
	
	@Override
	public void authenticateUser(String userName, String password) throws Exception{
		LoginDTO user1=new LoginDTO();
		user1=userDAO.authenticateUser(userName,password);
//		String status=env.getProperty("Service.INVALID_USERNAME");
		if(user1==null) {
			throw new Exception("Service.INVALID_USERNAME_OR_PASSWORD");
		
		}
		
		
		}
		
		
	}

	
