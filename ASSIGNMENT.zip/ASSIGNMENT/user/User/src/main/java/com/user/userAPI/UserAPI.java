package com.user.userAPI;

import org.json.simple.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.user.model.LoginDTO;
import com.user.model.UserDTO;
import com.user.service.UserService;



@RestController
@CrossOrigin

@RequestMapping(value="/user")
public class UserAPI {

@Autowired
private Environment env;

	@Autowired
	UserService userService;
	


	@PostMapping(value="/userSignup" )
	public JSONObject registerUser(@RequestBody UserDTO userDetails) throws Exception {
	try {
		 userService.addUser(userDetails);
		 String name=userDetails.getUserName();
		 JSONObject j=new JSONObject();
		 j.put(name,"successfully_added");
		 return j;
		 
	} catch (Exception e) {
		throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
    }
	}
	
	@PostMapping(value = "/userlogin")
	public JSONObject authenticateUser(@RequestBody LoginDTO logindetails) throws Exception{
		JSONObject j=new JSONObject();
			try {
				
//			String status=env.getProperty("Service.AUTHENTICATE_SUCCESS");
			
			userService.authenticateUser(logindetails.getUserName(),logindetails.getPassword());
			String name=logindetails.getUserName();
			j.put(name, "successfully_authenticated");
			
			return j;	
			}
			catch(Exception e) {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
			}
			}
	
	}
	
