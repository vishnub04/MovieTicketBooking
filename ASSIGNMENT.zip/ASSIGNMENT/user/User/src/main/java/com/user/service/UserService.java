package com.user.service;

import com.user.model.LoginDTO;
import com.user.model.UserDTO;

public interface UserService {
public void addUser(UserDTO user) throws Exception;
public void authenticateUser(String userName, String password) throws Exception;

}
