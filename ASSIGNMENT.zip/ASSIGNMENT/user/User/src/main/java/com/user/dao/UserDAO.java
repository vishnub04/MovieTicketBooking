package com.user.dao;


import com.user.model.LoginDTO;
import com.user.model.UserDTO;

public interface UserDAO {
	public void addUser(UserDTO user)throws Exception;
	public LoginDTO authenticateUser(String userName, String password)throws Exception;
	public UserDTO getUser(String userName) throws Exception;
}
