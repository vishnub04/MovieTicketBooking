package com.user.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.user.entity.UserEntity;
import com.user.model.LoginDTO;
import com.user.model.UserDTO;


@Repository
public class UserDAOImpl implements UserDAO{
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void addUser(UserDTO user)throws Exception{
		UserEntity userEntity=new UserEntity();
		userEntity.setUserName(user.getUserName());
		userEntity.setPassword(user.getPassword());
		userEntity.setAge(user.getAge());
		userEntity.setEmailId(user.getEmailId());
		userEntity.setPhoneNumber(user.getPhoneNumber());
		em.persist(userEntity);
	}
	
	@Override
	public LoginDTO authenticateUser(String userName, String password) throws Exception {		
		
		Query q=em.createQuery("select u from UserEntity u where u.userName=?1 and u.password=?2");
		q.setParameter(1,userName);
		q.setParameter(2,password);
		List<UserEntity>entityList=q.getResultList();
		
		if(entityList.isEmpty()) {
			return null;
		}
		UserEntity userEntity=entityList.get(0);
		if(userEntity!=null) {
		LoginDTO user=new LoginDTO();
		user.setPassword(userEntity.getPassword());
		user.setUserName(userEntity.getUserName());
		
		
		return user;
		}return null;

	}
	@Override
	public UserDTO getUser(String userName) throws Exception{
		UserEntity userEntity=em.find(UserEntity.class,userName);
		if(userEntity==null) return null;
		else {
		UserDTO userVer=new UserDTO();
		userVer.setUserName(userEntity.getUserName());
		userVer.setPassword(userEntity.getPassword());
		userVer.setAge(userEntity.getAge());
		userVer.setPhoneNumber(userEntity.getPhoneNumber());
		userVer.setEmailId(userEntity.getEmailId());
		return userVer;
		}
	}

	
	
}
