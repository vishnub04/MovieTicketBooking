package com.movie.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.movie.entity.MovieEntity;
import com.movie.entity.ShowEntity;
import com.movie.model.MovieDTO;
import com.movie.model.ShowDTO;


@Repository

public class MovieDAOImpl implements MovieDAO{

	@PersistenceContext
	private EntityManager em;
	
	//=======================add movie=================================================
	@Override
	public void addMovie(MovieDTO movie) throws Exception{
		
		MovieEntity movieEntity=new MovieEntity();
		movieEntity.setMovieName(movie.getMovieName());
		movieEntity.setLanguage(movie.getLanguage());
		movieEntity.setGenre(movie.getGenre());
		em.persist(movieEntity);
	}
	
	//==============================update Movie==================================
	@Override
	public Boolean updateMovie(MovieDTO movie) throws Exception {
		MovieEntity movieEntity=em.find(MovieEntity.class, movie.getMovieName());
		if(movieEntity==null) {
			return false;
		}
		movieEntity.setGenre(movie.getGenre());
		movieEntity.setLanguage(movie.getLanguage());
		Query q=em.createQuery("select u from MovieEntity u  where u.movieName=:movieName");
		q.setParameter("movieName",movieEntity.getMovieName());
		List<MovieEntity> movieList=q.getResultList();
		for(MovieEntity a:movieList) {
			a.setLanguage(movieEntity.getLanguage());
			a.setGenre(movieEntity.getGenre());
			return true;
		}return false;
		
	}
	//==============================delete movie==================================
	@Override
	public Integer deleteMovie(MovieDTO movie) throws Exception{
		MovieEntity movieEntity=em.find(MovieEntity.class, movie.getMovieName());
		
		if(movieEntity!=null) {
			String q="select d from ShowEntity d where d.movieName=?1 ";
			
			Query query1=em.createQuery(q);
			query1.setParameter(1,movie.getMovieName());
			
			
			List<ShowEntity> showList=query1.getResultList();
			if(showList.isEmpty()) {
			
			em.remove(movieEntity);
		
		}
			if(!showList.isEmpty()) {
				return 2;
			}
			
		
		}
		return 3;
		}
	
	
	
	
	//==============================get all Movie===============================

@Override
public List<MovieDTO> getMovie() throws Exception{
	
	List<MovieDTO> returnList=new ArrayList<MovieDTO>();
	Query query=em.createQuery("select u from MovieEntity u");
	List<MovieEntity> movieEntity=query.getResultList();
	for(MovieEntity a: movieEntity) {
		MovieDTO movieData=new MovieDTO();
		movieData.setMovieName(a.getMovieName());
		movieData.setLanguage(a.getLanguage());
		movieData.setGenre(a.getGenre());
		returnList.add(movieData);
	}
	return returnList;
}

//=======================add show=================================================

@Override
public Boolean addShow(ShowDTO show) throws Exception{
	String q="select d from ShowEntity d where d.showingTime=?1 and d.theatreName=?2 and d.showingDate=?3";
	Query query1=em.createQuery(q);
	query1.setParameter(1, show.getShowingTime());
	query1.setParameter(2, show.getTheatreName());
	query1.setParameter(3, show.getShowingDate());
	List<ShowEntity> showList=query1.getResultList();
	if(showList.isEmpty()) {
		
ShowEntity showDetails=new ShowEntity();
showDetails.setMovieName(show.getMovieName());
showDetails.setShowingId(show.getShowingId());
showDetails.setShowingDate(show.getShowingDate());
showDetails.setShowingTime(show.getShowingTime());
showDetails.setTheatreName(show.getTheatreName());
showDetails.setRemainingSeats(show.getRemainingSeats());
em.persist(showDetails);
return true;
}return false;
}


//=======================delete show=================================================
@Override
public Boolean deleteShow(ShowDTO show) throws Exception{
	ShowEntity showEntity=em.find(ShowEntity.class, show.getShowingId());
	if(showEntity!=null) {
		em.remove(showEntity);
       return true;
       }
	return false;
}
//=======================check movie=================================================
@Override
public Boolean checkMovie(MovieDTO movie) throws Exception{
	MovieEntity moviename=em.find(MovieEntity.class,movie.getMovieName());
	if(moviename!=null) {
		return false;
	}return true;
}
}





