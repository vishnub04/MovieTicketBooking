package com.movie.dao;

import java.util.List;

import com.movie.model.MovieDTO;
import com.movie.model.ShowDTO;

public interface MovieDAO {
	public void addMovie(MovieDTO movie) throws Exception;
	public Boolean updateMovie(MovieDTO movie) throws Exception;
	public Integer deleteMovie(MovieDTO movie) throws Exception;
	public List<MovieDTO> getMovie() throws Exception;
	public Boolean addShow(ShowDTO show) throws Exception;
	public Boolean deleteShow(ShowDTO show) throws Exception;
	public Boolean checkMovie(MovieDTO movie) throws Exception;
}
