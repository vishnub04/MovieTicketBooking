package com.movie.service;

import java.util.List;

import com.movie.model.MovieDTO;
import com.movie.model.ShowDTO;

public interface MovieService {
	public void addMovie(MovieDTO movie) throws Exception;
	public void updateMovie(MovieDTO movie) throws Exception;
	public void deleteMovie(MovieDTO movie) throws Exception;
	public List<MovieDTO> getMovie() throws Exception;
	public void addShow(ShowDTO show) throws Exception;
	public void deleteShow(ShowDTO show) throws Exception;

}
