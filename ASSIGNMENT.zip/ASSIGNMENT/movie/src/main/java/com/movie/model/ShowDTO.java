package com.movie.model;

public class ShowDTO {
private Integer showingId;
private String showingTime;
private String showingDate;
private String movieName;
private String theatreName;
private Integer remainingSeats;
public Integer getRemainingSeats() {
	return remainingSeats;
}
public void setRemainingSeats(Integer remainingSeats) {
	this.remainingSeats = remainingSeats;
}
public Integer getShowingId() {
	return showingId;
}
public void setShowingId(Integer showingId) {
	this.showingId = showingId;
}
public String getShowingTime() {
	return showingTime;
}
public void setShowingTime(String showingTime) {
	this.showingTime = showingTime;
}
public String getShowingDate() {
	return showingDate;
}
public void setShowingDate(String showingDate) {
	this.showingDate = showingDate;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getTheatreName() {
	return theatreName;
}
public void setTheatreName(String theatreName) {
	this.theatreName = theatreName;
}

}
