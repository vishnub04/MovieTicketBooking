package com.movie.api;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.movie.model.MovieDTO;
import com.movie.model.ShowDTO;
import com.movie.service.MovieServiceImpl;

@RestController
@CrossOrigin
@RequestMapping(value="/movie")
public class MovieAPI {
	
@Autowired
Environment env;
@Autowired
MovieServiceImpl  movieService;
	
	
	//=====================================add movie====================================================//
	
	@PostMapping(value="/addMovie")
	public JSONObject addMovie(@RequestBody MovieDTO movie) throws Exception{
		try {
			movieService.addMovie(movie);
			JSONObject j=new JSONObject();
			String name=movie.getMovieName();
			j.put(name,"successfully_added");
		return j;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
	//=====================================update movie====================================================//
	
	@PostMapping(value="/updateMovie")
	public JSONObject updateMovie(@RequestBody MovieDTO movie) throws Exception{
		try {
			movieService.updateMovie(movie);
			JSONObject j=new JSONObject();
			String name=movie.getMovieName();
			j.put(name,"successfully_updated");
		return j;
		}catch(Exception e) {
			System.out.println(env.getProperty(e.getMessage()));
			throw new Exception(env.getProperty(e.getMessage()));
		}
	
		}
	
	
	
	
	
	
	
	
	
	//=====================================delete movie====================================================//
	@PostMapping(value="/deleteMovie")
	public JSONObject deleteMovie(@RequestBody MovieDTO movie) throws Exception{
		try {
			movieService.deleteMovie(movie);
			JSONObject j=new JSONObject();
			String name=movie.getMovieName();
			j.put(name,"successfully_deleted");
			 return j;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
	//=====================================get all  movie====================================================//
	
	@GetMapping(value="/getMovie")
	public ResponseEntity<List<MovieDTO>> getMovie() throws Exception{
		try {
		List<MovieDTO> returnList=new ArrayList<MovieDTO>();
		returnList=movieService.getMovie();
		ResponseEntity<List<MovieDTO>> movieList=new ResponseEntity<List<MovieDTO>>(returnList,HttpStatus.OK);
		
		return movieList;
	}catch(Exception e) {
		throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
	}
}
	
	
	//=====================================add show    ====================================================//
	
	@PostMapping(value="/addShow")
	public JSONObject addShow(@RequestBody ShowDTO show) throws Exception{
		try {
			movieService.addShow(show);
			JSONObject p=new JSONObject();
			p.put("Show","successfully_added");
		return p;
		}
		catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
	
	//=======================delete show=================================================
	
	@PostMapping(value="/deleteShow")
	public JSONObject deleteShow(@RequestBody ShowDTO show) throws Exception{
		try {
			movieService.deleteShow(show);
			JSONObject j=new JSONObject();
			 j.put("Show","successfully_deleted");
			 return j;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
}
