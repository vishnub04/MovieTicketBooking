package com.movie.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.movie.dao.MovieDAOImpl;
import com.movie.model.MovieDTO;
import com.movie.model.ShowDTO;

@Service
@Transactional
public class MovieServiceImpl implements MovieService{
	@Autowired
	MovieDAOImpl movieDAO;
	
	//=======================add movie=================================================
		@Override
		public void addMovie(MovieDTO movie) throws Exception{
	
	try {
		Boolean a;
		a=movieDAO.checkMovie(movie);
		if(a==true) {
			movieDAO.addMovie(movie);
		}
		if(a==false) {
			throw new Exception("Service.MOVIE_ALREADY_EXISTS");
		}
	}
	catch(Exception e) {
		throw e;
	}
}
		
		
		
		//=======================add movie=================================================
		
		
		@Override
		public void updateMovie(MovieDTO movie) throws Exception{
			
				Boolean a;
				a=movieDAO.updateMovie(movie);
				if(a==false) {
					throw new Exception("Service.MOVIE_DOES_NOT_EXIST");
				}
			
		}
		
		
		
		
		
		//==============================delete movie==================================
		@Override
		public void deleteMovie(MovieDTO movie) throws Exception{
			Integer a=movieDAO.deleteMovie(movie);
			if(a==2) {
				throw new Exception("Service.MOVIE_CANNOT_DELETE_AS_SHOW_EXIST");
			}
			if(a==3) {
				throw new Exception("Service.MOVIE_DOES_NOT_EXIST");
			}
		}
		
		
		
		
		//==============================get all Movie===============================

		@Override
		public List<MovieDTO> getMovie() throws Exception{
			List<MovieDTO> returnList=new ArrayList<MovieDTO>();
			returnList=movieDAO.getMovie();
			if(returnList.isEmpty()) {
				throw new Exception("Service.NO_MOVIES_IN_THE_LIST");
			}
			return returnList;
		}
		
		//==============================add show===============================
		
		@Override
		public void addShow(ShowDTO show) throws Exception{
	
		Boolean a;
		a=movieDAO.addShow(show);
		if(a==false) {
		throw new Exception("Service.SHOW_ALREADY_ALLOWTED");	
		}
	
	}
		

		
		
		//==============================delete show===============================
		@Override
		public void deleteShow(ShowDTO show) throws Exception{
		
	Boolean a;
				a=movieDAO.deleteShow(show);
				if(a==false) {
					throw new Exception("Service.SHOW_DOES_NOT_EXIST");
				}
		
			
		}
		
//		
		
}






		

