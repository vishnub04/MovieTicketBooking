package com.booking.service;

import java.util.List;

import com.booking.model.BookingDTO;

public interface BookingService {
	public Integer addBooking(BookingDTO booking) throws Exception;
	public void deleteBooking(BookingDTO booking) throws Exception;
	public List<BookingDTO> getBooking(BookingDTO booking) throws Exception;
}
