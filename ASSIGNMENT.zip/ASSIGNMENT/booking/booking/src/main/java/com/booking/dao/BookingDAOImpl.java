package com.booking.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.booking.entity.BookingEntity;
import com.booking.entity.MovieEntity;
import com.booking.entity.ReportsEntity;
import com.booking.entity.ShowEntity;
import com.booking.entity.TheatreEntity;
import com.booking.entity.UserEntity;
import com.booking.model.BookingDTO;


@Repository
public class BookingDAOImpl implements BookingDAO {
	@PersistenceContext
	private EntityManager em;

	@Override
	public Integer addBooking(BookingDTO booking) throws Exception {
		BookingEntity bookingEntity =new BookingEntity ();
		TheatreEntity theatreEntity=new TheatreEntity();
//		UserEntity userEntity=new UserEntity();
//		MovieEntity movieEntity=new MovieEntity();
		ReportsEntity reportsEntity=new ReportsEntity();
//		ShowEntity showEntity=new ShowEntity();
		System.out.println("1");
		
		
		
		Query q=em.createQuery("select u from ShowEntity u  where u.movieName=?1 and u.theatreName=?2 and u.showingTime=?3");
		q.setParameter( 1,booking.getMovieName());
		q.setParameter( 2,booking.getTheatreName());
		q.setParameter( 3,booking.getShowingTime());
		List<ShowEntity> showList=q.getResultList();
		ShowEntity data=showList.get(0);
		System.out.println("2");
		if(!showList.isEmpty() && data.getRemainingSeats()>booking.getSeatsBooked()) {
			bookingEntity.setUserName(booking.getUserName());
			bookingEntity.setShowingTime(booking.getShowingTime());
			bookingEntity.setBookingDate(booking.getBookingDate());
			bookingEntity.setMovieName(booking.getMovieName());
			bookingEntity.setTheatreName(booking.getTheatreName());
			bookingEntity.setSeatsBooked(booking.getSeatsBooked());
			System.out.println(booking.getTheatreName());
			System.out.println("3");
			Query query=em.createQuery("select a.price from TheatreEntity a where a.theatre_name=:tname");
			query.setParameter("tname",booking.getTheatreName());
			System.out.println("4");
			Integer ticketprice=(Integer)query.getSingleResult();
			System.out.println(ticketprice);
			Integer totalprice=booking.getSeatsBooked()*ticketprice;
			
			bookingEntity.setTotalPrice(totalprice);
			
			em.persist(bookingEntity);
			
			Integer changeSeat=(data.getRemainingSeats())-(booking.getSeatsBooked());
			
			for(ShowEntity a:showList) {
			a.setRemainingSeats(changeSeat);
			}
			reportsEntity.setBookingId(bookingEntity.getBookingId());
			reportsEntity.setUserName(booking.getUserName());
			reportsEntity.setShowingTime(booking.getShowingTime());
			reportsEntity.setBookingDate(booking.getBookingDate());
			reportsEntity.setMovieName(booking.getMovieName());
			reportsEntity.setTheatreName(booking.getTheatreName());
			reportsEntity.setSeatsBooked(booking.getSeatsBooked());
			reportsEntity.setTotalPrice(totalprice);
			reportsEntity.setStatus("Booked");
			em.persist(reportsEntity);
			
			
			return bookingEntity.getBookingId();
			}return 0;
		
		
	}
//====================================DELETE BOOKINNG===============================================================
	@Override
	public void deleteBooking(BookingDTO booking) throws Exception {
		BookingEntity bookingEntity=em.find(BookingEntity.class, booking.getBookingId());
		if(bookingEntity!=null) {
			em.remove(bookingEntity);
		
			
			
			
		
		Query query=em.createQuery("select a from ReportsEntity a where a.bookingId=:bookingID");
		query.setParameter("bookingID",booking.getBookingId());
		List<ReportsEntity> reportList=query.getResultList();
		for(ReportsEntity a:reportList) {
			a.setStatus("Cancelled");
		}
		Query q=em.createQuery("select u from ShowEntity u  where u.movieName=?1 and u.theatreName=?2 and u.showingTime=?3");
		q.setParameter( 1,booking.getMovieName());
		q.setParameter( 2,booking.getTheatreName());
		q.setParameter( 3,booking.getShowingTime());
		List<ShowEntity> showList=q.getResultList();
		ShowEntity data=showList.get(0);
		
		Integer changeSeat=(data.getRemainingSeats())+(booking.getSeatsBooked());
		
		for(ShowEntity a:showList) {
		a.setRemainingSeats(changeSeat);
		}
		}
	}
		//====================================GET BOOKINNG===============================================================		
		@Override
	public List<BookingDTO> getBooking(BookingDTO booking) throws Exception {
		ShowEntity showEntity=new ShowEntity();
		Query q=em.createQuery("select u from BookingEntity u  where u.userName=?1");
		q.setParameter(1, booking.getUserName());
		List<BookingDTO> returnList=new ArrayList<BookingDTO>();
		List<BookingEntity> bookedMovies=q.getResultList();
		for(BookingEntity a:bookedMovies) {
			
			BookingDTO details=new BookingDTO();
			details.setUserName(a.getUserName());
			details.setBookingDate(a.getBookingDate());
			details.setBookingId(a.getBookingId());
			details.setMovieName(a.getMovieName());
			details.setSeatsBooked(a.getSeatsBooked());
			details.setShowingTime(a.getShowingTime());
			details.setTheatreName(a.getTheatreName());
			details.setTotalPrice(a.getTotalPrice());
			returnList.add(details);
		}
		return returnList;
	}
}
