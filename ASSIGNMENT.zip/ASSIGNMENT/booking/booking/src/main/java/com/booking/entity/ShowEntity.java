package com.booking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="showing")
public class ShowEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="showing_id")
	private Integer showingId;
	
	@Column(name="showing_time")
	private String showingTime;
	
	@Column(name="showing_date")
	private String showingDate;
	
//	@ManyToOne(cascade=CascadeType.ALL)
	
//	
//	@ManyToOne(cascade=CascadeType.ALL)
	@Column(name="movie_name")
	private String movieName;
	
	@Column(name="theatre_name")
	private String theatreName;
	
	@Column(name="remaining_seats")
	private Integer remainingSeats;
	
	
	public Integer getRemainingSeats() {
		return remainingSeats;
	}

	public void setRemainingSeats(Integer remainingSeats) {
		this.remainingSeats = remainingSeats;
	}

	public Integer getShowingId() {
		return showingId;
	}

	public void setShowingId(Integer showingId) {
		this.showingId = showingId;
	}

	public String getShowingTime() {
		return showingTime;
	}

	public void setShowingTime(String showingTime) {
		this.showingTime = showingTime;
	}

	public String getShowingDate() {
		return showingDate;
	}

	public void setShowingDate(String showingDate) {
		this.showingDate = showingDate;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}


	
}
