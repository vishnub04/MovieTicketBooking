package com.booking.dao;

import java.util.List;

import com.booking.model.BookingDTO;

public interface BookingDAO {
	public Integer addBooking(BookingDTO booking) throws Exception;
	public void deleteBooking(BookingDTO booking) throws Exception;
	public List<BookingDTO> getBooking(BookingDTO booking) throws Exception ;
	}
