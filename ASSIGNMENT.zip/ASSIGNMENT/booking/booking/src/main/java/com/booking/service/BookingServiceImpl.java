package com.booking.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.booking.dao.BookingDAOImpl;
import com.booking.model.BookingDTO;

@Service
@Transactional
public class BookingServiceImpl implements BookingService{
@Autowired
BookingDAOImpl bookingDAO;
//=======================add Booking=================================================
@Override
public Integer addBooking(BookingDTO booking) throws Exception{
	Integer a;
		a=bookingDAO.addBooking(booking);
	if(a==0) {
		throw new Exception("Service.SHOW_CANNOT_BE_BOOKED");
	}
	return a;

}

		//=======================delete booking=================================================
				

@Override
public void deleteBooking(BookingDTO booking) throws Exception{
	
	bookingDAO.deleteBooking(booking);

}


@Override

public List<BookingDTO> getBooking(BookingDTO booking) throws Exception{
	List<BookingDTO> returnList=new ArrayList<BookingDTO>();
	returnList=bookingDAO.getBooking(booking);
	return returnList;
}
}