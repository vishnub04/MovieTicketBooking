package com.booking.api;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.booking.model.BookingDTO;
import com.booking.service.BookingServiceImpl;

@RestController
@CrossOrigin
@RequestMapping(value="/bookings")
public class BookingAPI {
	@Autowired
	Environment env;
	@Autowired
	BookingServiceImpl bookingService;
	
	//=====================================add booking====================================================//
	@PostMapping(value="/addBooking")
	public JSONObject addBooking(@RequestBody BookingDTO booking) throws Exception{
		try {
			Integer a;
			a=bookingService.addBooking(booking);
			JSONObject j=new JSONObject();
			j.put("Booking completed with bookingID:",a);
		return j;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
	
	
	
	
	
	
	
	
	
	
	//=====================================delete booking====================================================//
	
	@PostMapping(value="/deleteBooking")
	public JSONObject deleteBooking(@RequestBody BookingDTO booking) throws Exception{
		try {
			bookingService.deleteBooking(booking);
			JSONObject j=new JSONObject();
			j.put("booking","successfully_cancelled");
		return j;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
	
	
	
	
	
	
	
	
	
	
	//=====================================show booking====================================================//
	@PostMapping(value="/getBooking")
	public ResponseEntity<List<BookingDTO>> getBooking(@RequestBody BookingDTO booking) throws Exception{
		try {
			List<BookingDTO> returnList=new ArrayList<BookingDTO>();
			returnList=bookingService.getBooking(booking);
			ResponseEntity<List<BookingDTO>> bookingList=new ResponseEntity<List<BookingDTO>>(returnList,HttpStatus.OK);
			return bookingList;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
	}
	
	}
	}
